# mobilemenu
A stylesheet for quickly converting mouse-driven dropdown menus into unobtrusive and usable mobile navigation.
